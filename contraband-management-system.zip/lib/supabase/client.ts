import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

// Check if Supabase environment variables are available
export const isSupabaseConfigured =
  typeof process.env.NEXT_PUBLIC_SUPABASE_URL === "string" &&
  process.env.NEXT_PUBLIC_SUPABASE_URL.length > 0 &&
  typeof process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY === "string" &&
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY.length > 0

// Create a singleton instance of the Supabase client for Client Components
export const createClient = () => createClientComponentClient()

export const supabase = createClientComponentClient()

// Database types
export interface User {
  id: string
  email: string
  full_name: string
  badge_number?: string
  role: "admin" | "supervisor" | "field_officer" | "warehouse_manager" | "auditor"
  department?: string
  phone?: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface ContrabandItem {
  id: string
  seizure_number: string
  category_id: string
  item_name: string
  description?: string
  quantity: number
  unit?: string
  estimated_value?: number
  weight_kg?: number
  status: "seized" | "in_custody" | "under_investigation" | "pending_destruction" | "destroyed" | "released"
  seizure_date: string
  seizure_location?: string
  gps_latitude?: number
  gps_longitude?: number
  seized_by: string
  case_number?: string
  court_case_number?: string
  barcode?: string
  rfid_tag?: string
  storage_location?: string
  created_at: string
  updated_at: string
}

export interface Message {
  id: string
  from_user_id: string
  to_user_id: string
  subject?: string
  content: string
  priority: "low" | "normal" | "high" | "urgent"
  message_type: "general" | "approval_request" | "status_update" | "alert"
  contraband_id?: string
  is_read: boolean
  requires_response: boolean
  parent_message_id?: string
  created_at: string
  read_at?: string
}
